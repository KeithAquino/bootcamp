import { Component } from "react";

class Election extends Component {
  constructor(props) {
    super(props);
    this.state = {
      mayor1: 0,
      mayor2: 0,
      vice1: 0,
      vice2: 0,
    };
  }
  getmayorVote = (event) => {
    this.setState({
      mayor: event.target.value,
    });
  };

  getViceVote = (event) => {
    this.setState({
      vice: event.target.value,
    });
  };

  submitVotes = (event) => {
    event.preventDefault();
    const { mayor, vice } = this.state;

    if (mayor) {
      this.setState((state) => ({
        [mayor]: state[mayor] + 1,
      }));
    }

    if (vice) {
      this.setState((state) => ({
        [vice]: state[vice] + 1,
      }));
    }
  };

  render() {
    return (
      <>
        <h1>Voting Form</h1>
        <form onSubmit={this.submitVotes}>
          <h2>Mayor</h2>
          <label>
            <input
              type="radio"
              name="mayor"
              value="mayor1"
              onChange={this.getmayorVote}
            />
            Dina Pili
          </label>
          <br />
          <label>
            <input
              type="radio"
              name="mayor"
              value="mayor2"
              onChange={this.getmayorVote}
            />
            Lucky Chan
          </label>
          <h2>Vice Mayor</h2>
          <label>
            <input
              type="radio"
              name="vice"
              value="vice1"
              onChange={this.getViceVote}
            />
            Pat Tumbakita
          </label>
          <br />
          <label>
            <input
              type="radio"
              name="vice"
              value="vice2"
              onChange={this.getViceVote}
            />
            Ben Eko
          </label>
          <br />
          <input type="submit" class="btn btn-primary" />
        </form>
        <div>
          <h1>Vote Record</h1>
          <table class="table table-borderless">
            <thead>
              <tr>
                <th>Name</th>
                <th>Position</th>
                <th>Total Votes</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Dina Pili</td>
                <td>Mayor</td>
                <td>{this.state.mayor1}</td>
              </tr>
              <tr>
                <td>Lucky Chan</td>
                <td>Mayor</td>
                <td>{this.state.mayor2}</td>
              </tr>
              <tr>
                <td>Pat Tumbakita</td>
                <td>Vice Mayor</td>
                <td>{this.state.vice1}</td>
              </tr>
              <tr>
                <td>Ben Eko</td>
                <td>Vice Mayor</td>
                <td>{this.state.vice2}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </>
    );
  }
}

export default Election;
