const pets = [
  {
    id: 0,
    species: "dog",
    eating_habit: "omnivore",
    pet_name: "Browny",
  },
  {
    id: 1,
    species: "goat",
    eating_habit: "herbivore",
    pet_name: "Kiddy",
  },
  {
    id: 2,
    species: "fennec fox",
    eating_habit: "carnivore",
    pet_name: "Foxy",
  },
  {
    id: 3,
    species: "rabbit",
    eating_habit: "herbivore",
    pet_name: "Bunny",
  },
  {
    id: 4,
    species: "dog",
    eating_habit: "omnivore",
    pet_name: "Whitey",
  },
];

module.exports = { pets };
