const pets = [
  {
    id: 0,
    image: "img/dog.jpg",
    species: "dog",
    eating_habit: "omnivore",
    pet_name: "Brownie",
  },
  {
    id: 1,
    image: "img/cat1.jpg",
    species: "cat",
    eating_habit: "carnivore",
    pet_name: "Luna",
  },
  {
    id: 2,
    image: "img/cat2.jpg",
    species: "cat",
    eating_habit: "carnivore",
    pet_name: "Sunny",
  },
  {
    id: 3,
    image: "img/parrot.jpg",
    species: "parrot",
    eating_habit: "omnivore",
    pet_name: "Polly",
  },
  {
    id: 4,
    image: "img/goldfish.jpg",
    species: "goldfish",
    eating_habit: "omnivore",
    pet_name: "Goldy",
  },
];

module.exports = { pets };
